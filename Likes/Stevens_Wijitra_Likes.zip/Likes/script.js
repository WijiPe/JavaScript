var count = 1;
var countElement1 = document.querySelector("#count");

function add1(){
    count++;
    countElement1.innerText = count +" "+ "Likes";
    console.log(count);
}

var count2 = 1;
var countElement2 = document.querySelector("#count2");

function add2(){
    count2++;
    countElement2.innerText = count2 +" "+ "Likes";
    console.log(count2);
}

var count3 = 1;
var countElement3 = document.querySelector("#count3");

function add3(){
    count3++;
    countElement3.innerText = count3 +" "+ "Likes";
    console.log(count3);
}
