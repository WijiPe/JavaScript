function displayAlert(MessageAlert) {
    alert(MessageAlert);
}

function logOut(element){
    element.innerText="logout";
}

function hide(element) {
    element.remove();
}