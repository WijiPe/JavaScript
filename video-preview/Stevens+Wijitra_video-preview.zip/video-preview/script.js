var x = document.getElementByClass("placeholder")

function over(element) {
    x.play();    
}
    
function out(element) {
    x.pause();   
}
