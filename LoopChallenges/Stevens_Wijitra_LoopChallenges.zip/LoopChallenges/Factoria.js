sum = 1
    for (var i = 1; i <13; i++){
        sum = sum*i
        console.log(i);
    }
console.log(sum);