sum = 0
    for (var i = 1; i <101; i++){
        sum = sum+i
        console.log(i);
    }
console.log(sum);